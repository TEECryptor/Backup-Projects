///////////////////////////////////////////////////////////////////////////////

// AS_Storage.h

// Copyright (c) 2001 - 2006, Sonic Solutions.  All rights reserved.

///////////////////////////////////////////////////////////////////////////////


#ifndef		__AS_Storage_helper_h__
#define		__AS_Storage_helper_h__

#ifndef __cplusplus
#error AS_Storage can only be used from C++ or Objective-C++ files
#endif

#include <string>

#include <AS_Storage/AS_StorageError.h>
#include <AS_Storage/AS_StorageTypes.h>
#include <AS_Storage/AS_StringHelper.h>
#include <AS_Storage/AS_Storage.h>
#include <AS_Storage/AS_StorageDevice.h>
#include <AS_Storage/AS_Volume.h>
#include <AS_Storage/AS_File.h>
#include <AS_Storage/AS_Format.h>
#include <AS_Storage/AS_Audio.h>
#include <AS_Storage/AS_AudioFile.h>
#include <AS_Storage/AS_Volume_Image.h>
#include <AS_Storage/AS_StorageDevice_Raw.h>

#endif //__AS_Storage_helper_h__
